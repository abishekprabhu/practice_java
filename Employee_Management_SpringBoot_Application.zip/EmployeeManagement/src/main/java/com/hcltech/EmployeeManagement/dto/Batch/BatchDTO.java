package com.hcltech.EmployeeManagement.dto.Batch;

import lombok.Data;

@Data
public class BatchDTO {
    private Long id;
    private String batchCode;
}
