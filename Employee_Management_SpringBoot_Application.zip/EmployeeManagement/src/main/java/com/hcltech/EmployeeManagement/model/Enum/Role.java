package com.hcltech.EmployeeManagement.model.Enum;

public enum Role {
    JAVA_FSD,
    PYTHON_FSD,
    DOTNET_FSD,
    DEVOPS,
    MANAGER,
    ADMIN,
    HR
}
