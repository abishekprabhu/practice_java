package com.hcltech.EmployeeManagement.dto.Mark.Score;

import lombok.Data;

@Data
public class ScoreDTO {
    private String employeeName;
    private Integer score;
}
