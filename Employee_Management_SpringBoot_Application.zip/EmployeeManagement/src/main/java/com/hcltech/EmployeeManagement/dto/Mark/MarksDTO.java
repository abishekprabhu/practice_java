package com.hcltech.EmployeeManagement.dto.Mark;

import lombok.Data;

@Data
public class MarksDTO {
    private String examName;
    private Integer score;
}
